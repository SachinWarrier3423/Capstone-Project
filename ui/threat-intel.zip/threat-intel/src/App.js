import React from 'react';
import Dashboard from './Dashboard';

function App() {
  // Renders the Dashboard as our main (and only) page
  return <Dashboard />;
}

export default App;
